"""file for rdbex recovery. DO NOT DELETE, doing so could cause irrepairable damage."""
protected_header = ">>"

config_def = {"sep": "|", "ref": "[//", "banned_chars": [], "msg": "RdbEX"}
